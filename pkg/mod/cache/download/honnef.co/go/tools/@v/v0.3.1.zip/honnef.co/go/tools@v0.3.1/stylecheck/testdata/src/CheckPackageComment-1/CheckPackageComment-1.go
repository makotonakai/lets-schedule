package pkg // want `at least one file in a package should have a package comment`
